#include <string.h>
#include <stdio.h>
#include <stdlib.h>

char* ReadLine() {
	char c, * line = NULL;
	int counter = 0;
	while ((c = getchar()) != '\n')
	{
		counter++;
		line = realloc(line, counter * sizeof(char));
		if (line == NULL) {
			printf("MEM_GRESKA");
			exit(1);
		}
		line[counter - 1] = c;
	}
	if (counter == 0)return line;
	line = realloc(line, (counter + 1) * sizeof(char));
	line[counter] = '\0';
	return line;
}

char** ReadLines(int* n) {
	char** lines = NULL, * line;
	while ((line = ReadLine()) != NULL) {
		lines = realloc(lines, ++(*n) * sizeof(char*));
		if (line == NULL) {
			printf("MEM_GRESKA");
			exit(1);
		}
		lines[*n - 1] = line;
	}
	free(line);
	return lines;
}

int IsDate(char* string) {
	int num = 0;
	char* p = string;
	for (int i = 0; i < strlen(p); i++)if (p[i] == '-')num++;
	if (num != 2)return 0;
	return 1;
}

void ObradaDatuma(char* string, int add) {
	int flag = 0, day, month, year;
	char* temp;
	day = atoi(strtok(string, "-")) + add;
	month = atoi(strtok(NULL, "-"));
	temp = strtok(NULL, "-");
	year = atoi(temp);
	while (day > 28 && !flag)
	{
		switch (month)
		{
		case 2:
			if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) {
				if (day < 30 && flag++ == 0)break;
				day -= 29;
				month++;
				break;
			}
			day -= 28;
			month++;
			break;
		case 4:case 6:case 9:case 11:
			if (day < 31 && flag++ == 0)break;
			day -= 30;
			month++;
			break;
		default:
			if (day < 32 && flag++ == 0)break;
			day -= 31;
			month = month % 12 + 1;
			if (month == 1)year++;
			break;
		}
		if (flag)break;
	}
	printf("%02d-%02d-%04d", day, month, year);
	if (!isdigit(temp[strlen(temp) - 1]))printf("%c", temp[strlen(temp) - 1]);
}

void free_all(char** lines, int size) {
	for (int i = 0; i < size; i++)free(lines[i]);
	free(lines);
}

void UpdateDates(int dayOffset, char** stringDates, int n) {
	char* token, * pointer;
	for (int i = 0; i < n; i++)
	{
		int count = 0;
		token = strtok_s(stringDates[i], " ", &pointer);
		while (token != NULL) {
			if (count++ != 0)printf(" ");
			if (IsDate(token))ObradaDatuma(token, dayOffset);
			else printf("%s", token);
			token = strtok_s(NULL, " ", &pointer);
		}
		if (i != n - 1)printf("\n");
	}
}

int main() {
	int num_of_lines = 0, add, day, month, year;
	scanf("%d", &add);
	getchar();
	if (add < 1) {
		printf("GRESKA");
		return 0;
	}
	char** lines = ReadLines(&num_of_lines);
	if (add < 1 || num_of_lines == 0) {
		printf("GRESKA");
		return 0;
	}
	UpdateDates(add, lines, num_of_lines);
	free_all(lines, num_of_lines);
	return 0;
}