#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct Naucni_Rad {
	char* DOI_Broj;
	char* naslovRada;
	char* naslovCasopisa;
	int godinaIzdanja;
	struct Naucni_Rad* next;
};

typedef struct Naucni_Rad Rad;

Rad* ReadLine() {
	Rad* ret = malloc(sizeof(Rad));
	char* input = malloc(sizeof(char)), c;
	int var = 0, len = 0;
	while ((c = getchar()) != '\n')
	{
		if (c == ',')
		{
			switch (var++)
			{
			case 0:ret->DOI_Broj = input; break;
			case 1:ret->naslovRada = input; break;
			case 2:ret->naslovCasopisa = input; break;
			}
			input[len] = '\0';
			input = malloc(sizeof(char));
			len = 0;
			continue;
		}
		input[len++] = c;
		input = realloc(input, (len + 1) * sizeof(char));
	}
	if (var != 3) {
		free(ret);
		free(input);
		return NULL;
	}
	ret->godinaIzdanja = atoi(input);
	free(input);
	return ret;
}


Rad* Read() {
	Rad* head = NULL, * tail = NULL, * temp;
	head = ReadLine();
	if (head == NULL) {
		printf("GRESKA");
		exit(1);
	}
	tail = head;
	while ((temp = ReadLine()) != NULL)
	{
		tail->next = temp;
		tail = temp;
	}
	tail->next = NULL;
	return head;
}

int Provera(char* DOI) {
	char* ptr = NULL, *ptr2 = NULL;
	char* prefix = strtok_s(DOI, "/", &ptr), *suffix = strtok_s(NULL, "/", &ptr);
	char* first_part = strtok_s(prefix, ".", &ptr2), * second_part = strtok_s(NULL, ".", &ptr2);
	if (suffix == NULL || second_part == NULL || strlen(first_part) != 2 || first_part[0] != '1' || first_part[1] != '0' || second_part[0] == '0')return 0;
	return 1;
}

void Copy(Rad* Source, Rad* Destination) {
	Destination->DOI_Broj = Source->DOI_Broj;
	Destination->godinaIzdanja = Source->godinaIzdanja;
	Destination->naslovCasopisa = Source->naslovCasopisa;
	Destination->naslovRada = Source->naslovRada;
	Destination->next = NULL;
}

void Free(Rad* list) {
	Rad* temp;
	while (list != NULL)
	{
		temp = list->next;
		free(list->DOI_Broj);
		free(list->naslovCasopisa);
		free(list->naslovRada);
		free(list);
		list = temp;
	}
}

Rad* Sort(Rad* list) {
	Rad* sorted_list = malloc(sizeof(Rad));
	Copy(list, sorted_list);
	for (Rad* i = list->next; i != NULL; i = i->next)
	{
		int flag = 0;
		Rad* j, * last = NULL;
		for (j = sorted_list; j != NULL; j = j->next)
		{
			if (!strcmp(j->naslovCasopisa, i->naslovCasopisa))flag = 1;
			if (!strcmp(j->naslovCasopisa, i->naslovCasopisa) && (j->godinaIzdanja > i->godinaIzdanja ||
				j->godinaIzdanja == i->godinaIzdanja && strcmp(j->naslovRada, i->naslovRada) > 0)) {
				Rad* node = malloc(sizeof(Rad));
				Copy(i, node);
				node->next = j;
				if (last != NULL)last->next = node;
				else sorted_list = node;
				break;
			}
			if (strcmp(j->naslovCasopisa, i->naslovCasopisa) && flag)
			{
				Rad* node = malloc(sizeof(Rad));
				Copy(i, node);
				node->next = j;
				last->next = node;
				break;
			}
			last = j;
		}
		if (j == NULL) {
			Rad* node = malloc(sizeof(Rad));
			Copy(i, node);
			node->next = NULL;
			last->next = node;
		}
	}
	return sorted_list;
}

void Print(Rad* list) {
	char* Cur = list->naslovCasopisa;
	printf("%s\n", list->naslovCasopisa);
	for (Rad* i = list; i != NULL; i = i->next) {
		if (strcmp(i->naslovCasopisa, Cur)) {
			printf("%s\n", i->naslovCasopisa);
			Cur = i->naslovCasopisa;
		}
		printf("%s\n", i->naslovRada);
	}
}

int main() {
	Rad* list = Read(), * sorted_list;
	for (Rad* i = list; i != NULL; i = i->next)
		if (!Provera(i->DOI_Broj)) {
			printf("GRESKA");
			Free(list);
			Free(sorted_list);
			return 0;
		}
	sorted_list = Sort(list);
	Print(sorted_list);
	Free(list);
	Free(sorted_list);
	return 0;
}