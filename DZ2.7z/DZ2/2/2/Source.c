#include <stdio.h>
#include <stdlib.h>

void Clear(int* array, int n) {
	for (int i = 0; i < n; i++)array[i] = 0;
	return;
}

void Print_Niz(int niz[], int size) {
	for (int i = 0; i < size - 1; i++)
	{
		printf("%d ", niz[i]);
	}
	printf("%d\n", niz[size - 1]);
}

void Sort(int* array, int size) {
	for (int j = 0; j < size; j++)for (int k = j; k < size; k++)
		if (array[2 * j] * array[2 * j + 1] < array[2 * k] * array[2 * k + 1])
		{
			int temp = array[2 * j];
			array[2 * j] = array[2 * k];
			array[2 * k] = temp;
			temp = array[2 * j + 1];
			array[2 * j + 1] = array[2 * k + 1];
			array[2 * k + 1] = temp;
		}
}

void Free_All(int** matrix, int size, int* array) {
	for (int i = 0; i < size; i++)free(matrix[i]);
	free(matrix);
	free(array);
}

void Obrada(int** igraci, int* broj_poena, int broj_igraca, int card) {
	int max = 0, sum = 0, * maks_igrac = malloc(broj_igraca * sizeof(int)), brojac = 0;
	for (int j = 0; j < broj_igraca; j++)
	{
		if (igraci[j][card * 2] * igraci[j][card * 2 + 1] > max) {
			max = igraci[j][card * 2] * igraci[j][card * 2 + 1];
			Clear(maks_igrac, broj_igraca);
			maks_igrac[brojac = 0] = j;
			brojac++;
		}
		else if (igraci[j][card * 2] * igraci[j][card * 2 + 1] == max)maks_igrac[brojac++] = j;
		sum += igraci[j][card * 2] * igraci[j][card * 2 + 1];
	}
	for (int i = 0; i < brojac; i++) {
		printf("%d ", maks_igrac[i]);
		broj_poena[maks_igrac[i]] += sum / brojac;
	}
	printf("%d %d\n", max, sum / brojac);
	free(maks_igrac);
}

int main() {
	int broj_igraca, broj_karata;
	int **igraci, *broj_poena;
	scanf_s("%d %d", &broj_igraca, &broj_karata);
	if (broj_igraca < 1 || broj_karata < 1)return 0;
	igraci = malloc(broj_igraca * sizeof(int *));
	broj_poena = malloc(broj_igraca * sizeof(int));
	for (int i = 0; i < broj_igraca; i++)igraci[i] = malloc(broj_karata * 2 * sizeof(int));
	for (int i = 0; i < broj_igraca; i++)for (int j = 0; j < broj_karata; j++)
		scanf_s("%d %d", &igraci[i][2 * j], &igraci[i][2 * j + 1]);
	for (int i = 0; i < broj_igraca; i++)for (int j = 0; j < broj_karata; j++)
	{
		if (igraci[i][2 * j] > 14 || igraci[i][2 * j] < 2 || igraci[i][2 * j + 1] < 1 || igraci[i][2 * j + 1] > 4) {
			printf("GRESKA");
			Free_All(igraci, broj_igraca, broj_poena);
			return 0;
		}
	}
	for (int i = 0; i < broj_igraca; i++)Print_Niz(igraci[i], broj_karata * 2);
	for (int i = 0; i < broj_igraca; i++)Sort(igraci[i], broj_karata);
	for (int i = 0; i < broj_karata; i++)Obrada(igraci, broj_poena, broj_igraca, i);
	int maks = 0, igrac = -1;
	Print_Niz(broj_poena, broj_igraca);
	for (int i = 0; i < broj_igraca; i++)if (broj_poena[i] > maks)
	{
		maks = broj_poena[i];
		igrac = i;
	}
	printf("%d %d", igrac, maks);
	Free_All(igraci, broj_igraca, broj_poena);
	return 0;
}