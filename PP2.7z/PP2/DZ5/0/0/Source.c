#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#pragma warning(disable : 4996)

typedef struct Song {
	char* filename;
	char* name_of_author;
	char* title;
	int length;
	struct Song* next, *last;
}Song;

Song* Read(char* input_file, int max_len) {
	FILE* file = fopen(input_file, "r");
	if (file == NULL) {
		printf("DAT_GRESKA");
		exit(0);
	}
	char* filename = malloc(50), * name = malloc(30), * title = malloc(30);
	int length, number_of_entries;
	Song* list = NULL, *tail = NULL;
	fscanf(file, "%*[^\n]\n");
	fscanf(file, "NumberOfEntries=%d\n", &number_of_entries);
	while (number_of_entries--)
	{
		fscanf(file, "File%d=%[^\n]\nTitle%d=%[^-] - %[^\n]\nLength%d=%d\n", &length, filename, &length, name,
			title, &length, &length);
		if (max_len < length)continue;
		Song* node = malloc(sizeof(Song));
		filename = realloc(filename, strlen(filename) + 1);
		name = realloc(name, strlen(name) + 1);
		title = realloc(title, strlen(title) + 1);
		node->filename = filename;
		node->name_of_author = name;
		node->length = length;
		node->title = title;
		if (list == NULL)list->last = list->next = list = node;
		list->last->next = node;
		node->last = list->last;
		list->last = node;
		filename = malloc(50);
		name = malloc(30);
		title = malloc(30);
	}
	list->last->next = NULL;
	list->last = NULL;
	free(filename);
	free(name);
	free(title);
	fclose(file);
	return list;
}

void Copy(Song* Source, Song* Destination) {
	Destination->filename = Source->filename;
	Destination->length = Source->length;
	Destination->name_of_author = Source->name_of_author;
	Destination->title = Source->title;
}

void Sort(Song* list) {
	for (Song* i = list; i != NULL; i = i->next)
		for (Song* j = list; j != NULL; j = j->next)
			if (strcmp(j->name_of_author, i->name_of_author) > 0 ||
				(strcmp(j->name_of_author, i->name_of_author) == 0 && strcmp(j->title, i->title)) > 0) {
				Song* temp = malloc(sizeof(Song));
				Copy(j, temp);
				Copy(i, j);
				Copy(temp, i);
				free(temp);
			}
}

void Write(char* filename, Song* list) {
	FILE* file = fopen(filename, "w");
	fprintf(file, "#EXTM3U");
	for (Song* i = list; i != NULL; i = i->next)
		fprintf(file, "\n#EXTINF:%d,%s- %s\n%s", i->length, i->name_of_author, i->title, i->filename);
	fclose(file);
}

void Free(Song* list) {
	for (Song* i = list; i != NULL; i = i->next) {
		free(i->filename);
		free(i->name_of_author);
		free(i->title);
		free(i);
	}
}

int main(int argc, char* argv[]) {
	if (argc != 4) {
		printf("ARG_GRESKA");
		return 0;
	}
	char* input_file = argv[1], *output_file = argv[2];
	int length = atoi(argv[3]);
	Song* list = Read(input_file, length);
	Sort(list);
	Write(output_file, list);
	Free(list);
	return 0;
}