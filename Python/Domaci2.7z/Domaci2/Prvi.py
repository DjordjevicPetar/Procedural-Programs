class company:
    broj_licitacija = 0
    licitator = ""
    trenutna_cena = 0
    def __init__(self, str):
        str = str.split(",")
        self.id = int(str.pop(0))
        self.name = ""
        for s in range(len(str) - 1): self.name += str[s] + ","
        self.name = self.name[:-1]
        self.name = self.name.strip('"')
        str[-1] = str[-1][:-1]
        self.price = 0 if str[-1] == "" else int(str[-1])


    def licitirati(self, str):
        if max(self.trenutna_cena, float(str[1])) == self.trenutna_cena:
            return
        self.broj_licitacija += 1
        self.trenutna_cena = float(str[1])
        self.licitator = str[2]


    def __str__(self):
        out =  str(self.id) + " " + self.name + " " + "{0:.2f}".format(float(self.price))
        if self.broj_licitacija != 0:
            out += " " + str(self.broj_licitacija) + " " + "{0:.2f}".format(float(self.trenutna_cena))\
                   + " " + self.licitator
        return out



def main():
    companies = []
    with open(input()) as f:
        f.__next__()
        for row in f:
            companies.append(company(row))
    with open(input()) as f:
        f.__next__()
        for row in f:
            row = row.split()
            companies[int(row[0]) - 1].licitirati(row)
    with open("result.txt", "w") as f:
        for com in companies:
            f.write(str(com) + ("\n" if com.id != len(companies) else ""))


if __name__ == '__main__':
    main()