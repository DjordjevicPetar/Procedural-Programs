from datetime import date

#Klasa za instancu jednog coveka, za lakse skladistenje podataka
class citizen:
    #Konstruktor
    def __init__(self, arguments):
        self.name = arguments[0]
        self.surname = arguments[1]
        self.gender = arguments[2]
        splited_date = arguments[3].split("/")
        self.borning_date = date(int(splited_date[2]), int(splited_date[1]), int(splited_date[0]))
        self.education = arguments[4].strip()


#Klasa nivo edukacije
class education:
    #Konstruktor
    def __init__(self, level):
        self.level_of_education = level
        self.number_of_man = 0
        self.number_of_woman = 0


    #Implementacija string konverzije, radi lakseg ispisa podataka klase
    def __str__(self, total):
        men_and_women = (self.number_of_man + self.number_of_woman)
        percentage_of_woman = self.number_of_woman * 100 / (men_and_women if men_and_women != 0 else 1)
        percentage_of_man = self.number_of_man * 100 / (men_and_women if men_and_women != 0 else 1)
        return "{0} {1} {2} | {3:.2f} {4:.2f} | {5} {6:.2f}".format(self.level_of_education, self.number_of_woman,
            self.number_of_man, percentage_of_woman, percentage_of_man,
            men_and_women, men_and_women * 100 / total)


#Funkcija koja izracunava starost osobe
def Difference_of_Dates(bd):
    today = date(2021, 1, 1)
    years = today.year - bd.year
    if today.month < bd.month or (today.month == bd.month and today.day < bd.day):
        years -= 1
    return years


#Funkcija koja cita podatke
def Collect(file):
    citizens = []
    with open(file, "r") as f:
        f.__next__()
        for row in f:
            citizens.append(citizen(row.split(",")))
    return citizens


#Funkcija za obradjivanje podataka
def Statistics(citizens, bottom_limitation, upper_limitation):
    educations = {"Primary": education("Primary"), "Secondary": education("Secondary"),
                  "Bachelor": education("Bachelor"),
                  "Master": education("Master"), "PHD": education("PHD")}
    total = 0
    for person in citizens:
        if Difference_of_Dates(person.borning_date) >= bottom_limitation and \
                Difference_of_Dates(person.borning_date) <= upper_limitation:
            total += 1
            if person.gender == "M":
                educations[person.education].number_of_man += 1
            else:
                educations[person.education].number_of_woman += 1
    return educations, total


def main():
    citizens = []
    bottom_limitation, upper_limitation = 0, 500
    file = input()
    limit = input()
    try:
        citizens = Collect(file)
    except:
        print("DAT_GRESKA", end="")
        return -1
    try:
        if limit != "":
            bottom_limitation, upper_limitation = map(int, limit.split("-"))
    except:
        print("GRESKA", end="")
        return 1
    educations, total = Statistics(citizens, bottom_limitation, upper_limitation)
    with open("stats.txt", "w") as f:
        output = ""
        for key in educations.keys():
            output += educations[key].__str__(total) + "\n"
        f.write(output[:-1])


if __name__ == '__main__':
    main()
