def main():
    numbers = sorted(map(int, input().split(" ")))
    if 0 in numbers: return
    main_number = input()
    if main_number == "":return 1
    main_number = int(main_number)
    club_of_numbers = 0
    for divisor in range(1, int(main_number ** (1 / 2)) + 1):
        if main_number % divisor == 0: club_of_numbers += divisor + main_number / divisor
    club_of_numbers /= main_number
    solutions = []
    for number in numbers:
        sum = 0
        for divisor in range(1, int(number ** (1/2)) + 1):
            if number % divisor == 0:sum += divisor + number / divisor
        if sum / number == club_of_numbers: solutions.append(number)
    [print(x, end=" " if x != solutions[-1] else "") for x in solutions]



if __name__ == '__main__':
    main()