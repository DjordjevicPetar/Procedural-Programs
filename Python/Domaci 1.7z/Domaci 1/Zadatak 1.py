def main():
    length = int(input())
    days = [input().split() for x in range(length)]
    days = [(int(x) + int(y) + int(z)) / 3 for x, y, z in days if x[0] != "-" and y[0] != "-" and z[0] != "-"]
    for value in days:
        if value < 51:print("ZELENA")
        elif value < 101:print("ZUTA")
        elif value < 151:print("NARANDJASTA")
        elif value < 201:print("CRVENA")
        elif value < 301:print("LJUBICASTA")
        elif value < 501:print("BRAON")


if __name__ == '__main__':
    main()
