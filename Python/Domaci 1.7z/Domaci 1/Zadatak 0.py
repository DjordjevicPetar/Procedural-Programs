def main():
    complex_numbers = [(float(x.split()[0]), float(x.split()[1])) for x in input().split(",")]
    moduo = float(input())
    complex_numbers.sort(key=lambda complex:((complex[0]**2 + complex[1]**2)**(1/2)))
    for x, y in filter(lambda complex: (complex[0]**2 + complex[1]**2)**(1/2) > moduo, complex_numbers):
        if y > 0:print(f"{x:.2f} + j{y:.2f}")
        else:print(f"{x:.2f} - j{-y:.2f}")

if __name__ == '__main__':
    main()
