import math


def Input():
    #Upis
    return list(map(int, input().split()))


def Validation(array):
    #Proverava validnost unesenih podataka
    return True if len([1 for x in array if x < 1]) > 0 or len(array) == 0 else False


def Filter(array):
    #Filtrira neobilatne brojeve
    output = []
    for x in array:
        if is_obilat(x): output.append(x)
    return output


def is_obilat(num):
    #Proverava da li je broj obilatan
    sum_of_divisors = 1
    for i in range(2, math.ceil(num ** (1 / 2))):
        if num % i == 0: sum_of_divisors += i + num / i
    if sum_of_divisors > num:
        return True
    return False


def Print(array):
    #Ispis dobijenih vrednosti
    print(*sorted(array), end="")
    return 0


def main():
    array = Input()
    if Validation(array): return 0
    output_array = Filter(array)
    Print(output_array)


if __name__ == '__main__':
    main()
