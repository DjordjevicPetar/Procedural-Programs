#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma warning(disable : 4996)

typedef struct Patients {
	char* name, * surname;
	int day, month, year;
	float BMI;
	struct Patients* next;
}Patients;

Patients* Read(int low, int high) {
	FILE* file = fopen("patients.txt", "r");
	if (file == NULL) {
		printf("DAT_GRESKA");
		exit(0);
	}
	Patients* head = NULL, * tail = NULL, *tmp;
	char *name = malloc(20 * sizeof(char)), *surname = malloc(20 * sizeof(char));
	int day, month, year;
	float weight, height;
	while (fscanf(file, "%d-%d-%d %s %s %f %f", &day, &month, &year, name, surname, &weight, &height) == 7)
	{
		if (year < low || year > high)continue;
		tmp = malloc(sizeof(Patients));
		name = realloc(name, strlen(name) + 1);
		surname = realloc(surname, strlen(surname) + 1);
		tmp->year = year;
		tmp->month = month;
		tmp->day = day;
		tmp->name = name;
		tmp->surname = surname;
		tmp->BMI = weight / (height/100) / (height / 100);
		if (!head)tail = head = tmp;
		else tail = tail->next = tmp;
		tail->next = NULL;
		name = malloc(20 * sizeof(char));
		surname = malloc(20 * sizeof(char));
	}
	free(name);
	free(surname);
	fclose(file);
	return head;
}

void input(int* first, int* second) {
	char* temp = malloc(10 * sizeof(char));
	char c;
	int i = 0;
	while ((c = getchar()) != '-')temp[i++] = c;
	*first = atoi(temp);
	scanf("%d", second);
	free(temp);
}

void Copy(Patients* source, Patients* destination) {
	destination->BMI = source->BMI;
	destination->day = source->day;
	destination->month = source->month;
	destination->name = source->name;
	destination->surname = source->surname;
	destination->year = source->year;
}

Patients* Sort(Patients* list) {
	for (Patients* i = list; i != NULL; i = i->next) {
		for (Patients* j = i->next; j != NULL; j = j->next) {
			int older = j->year < i->year || (i->year == j->year && j->month < i->month) ||
				i->year == j->year && j->month == i->month && j->day < i->day;
			if (i->BMI < j->BMI || (i->BMI == j->BMI && older)) {
				Patients* temp = malloc((sizeof(Patients)));
				Copy(i, temp);
				Copy(j, i);
				Copy(temp, j);
				free(temp);
			}
		}
	}
	return list;
}

void main() {
	int lower_limit, upper_limit, num_of_outputs, j = 0;
	input(&lower_limit, &upper_limit);
	scanf("%d", &num_of_outputs);
	Patients* list = Read(lower_limit, upper_limit);
	list = Sort(list);
	FILE* file = fopen("high_bmi.txt", "w");
	for (Patients* i = list; i != NULL && ++j <= num_of_outputs; i = i->next)
		fprintf(file, "%02d-%02d-%d %s %s %.2f\n", i->day, i->month, i->year, i->name, i->surname, i->BMI);
	for (Patients* i = list; i != NULL;) {
		Patients* temp = i->next;
		free(i->name);
		free(i->surname);
		free(i);
		i = temp;
	}
	fclose(file);
}